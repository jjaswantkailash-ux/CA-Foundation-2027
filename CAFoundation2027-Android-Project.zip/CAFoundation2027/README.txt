CA FOUNDATION JANUARY 2027 - ANDROID PROJECT

This is an Android Studio project wrapping an offline-first study app in a WebView.
It is not yet a compiled APK. The build environment used to create this project did
not include the Android SDK / Android Gradle build tools.

BUILD APK ON WINDOWS
1. Install Android Studio (stable version) and its Android SDK Platform 35.
2. Extract this ZIP.
3. Android Studio > Open > select the CAFoundation2027 folder.
4. Wait for Gradle sync. If prompted, install the required SDK/build tools.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer app-debug.apk to your Redmi Note 8 and install it. If Android asks,
   allow installation from that file manager/source.

APP FEATURES
- Dashboard with 8-hour daily target and paper progress
- Chapter tracker for four CA Foundation papers
- Study session logging saved on-device
- Original starter MCQs with explanations
- 15-minute 10-question practice mock, score and answer review
- Performance and weak-chapter dashboard
- Starter revision notes

DATA & LIMITATIONS
- Progress is stored locally in the app WebView using localStorage. Clearing app
  storage or uninstalling may erase it. Export/backup is not implemented yet.
- The question bank and revision notes are starter content, not a complete test
  series or official ICAI material. Verify the January 2027 syllabus, amendments,
  RTPs, MTPs and question papers with ICAI's current official resources.
- The chapter lists are a broad starter checklist and should be checked against
  the exact applicable ICAI syllabus before relying on completeness.
